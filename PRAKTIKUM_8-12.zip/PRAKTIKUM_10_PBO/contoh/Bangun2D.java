package contoh;

public abstract class Bangun2D {
    public abstract void cetakLuas();
    public abstract void cetakKeliling();
}
