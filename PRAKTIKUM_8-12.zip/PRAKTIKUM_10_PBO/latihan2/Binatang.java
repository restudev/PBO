package latihan2;

abstract class Binatang {
    abstract void makan();
    abstract void tidur();
    void mati() {
        System.out.println("Mati..........");
    }
}
