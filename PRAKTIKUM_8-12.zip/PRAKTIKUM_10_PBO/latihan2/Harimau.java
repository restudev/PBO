package latihan2;

class Harimau extends Binatang {
    void makan() {
        System.out.println("Harimau Makan..........");
    }
    void tidur() {
        System.out.println("Harimau tidur..........");
    }
}
