package latihan1;

public class TeleponDemo {
    public static void main(String[]args){
        Handphone hp=new Handphone();
        hp.setNomor(8183434);

        hp.telpon();
        hp.setPixel(1024);
        hp.ambilGambar();
        hp.setGelombang("FM 101.2");
    }
}
    