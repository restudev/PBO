/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.restu.praktikum_10;

/**
 *
 * @author Restu
 */
public class TeleponDemo {

    public static void main(String[] args) {
        Handphone hp = new Handphone();
        hp.setNomor(8183434);

        hp.telpon();
        hp.setPixel(1024);
        hp.ambilGambar();
        hp.setGelombang("FM 101.2");
    }
}