/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.restu.praktikum_10;

/**
 *
 * @author Restu
 */
public interface Kamera {
    public void setPixel(float pixel);
    public void ambilGambar();
}