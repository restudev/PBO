/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.restu.praktikum_10;

/**
 *
 * @author Restu
 */
class Harimau extends Binatang {
    void makan() {
        System.out.println("Harimau Makan..........");
    }
    void tidur() {
        System.out.println("Harimau tidur..........");
    }
}
