/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.restu.praktikum_10;

/**
 *
 * @author Restu
 */
public class MejaMakan extends Meja {
    public int jmlKursi;
    
    void cetak() {
        System.out.println("Harga\t\t: " + harga);
        System.out.println("Bahan\t\t: " + bahan);
        System.out.println("Jumlah Kaki\t: " + jmlKursi);
        System.out.println("Jumlah Kaki\t: " + jmlKaki);
        System.out.println("Bayar\t\t: " + (harga));
    }
}


