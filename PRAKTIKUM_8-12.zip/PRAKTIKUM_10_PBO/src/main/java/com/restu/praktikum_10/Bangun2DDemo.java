/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.restu.praktikum_10;

/**
 *
 * @author Restu
 */
public class Bangun2DDemo {

    public static void main(String[] args) {
        BujurSangkar bs = new BujurSangkar(5);
        bs.cetakKeliling();
        bs.cetakLuas();
    }
}
