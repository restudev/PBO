public class Pesawat {
    public int sayap = 2;
    public int ekor = 1;

    public Pesawat() {
        System.out.println("object Pesawat dibuat............");
    }

    public void terbang() {
        System.out.println("Terbang..........");
    }

    public void mendarat() {
        System.out.println("Mendarat..........");
    }
}