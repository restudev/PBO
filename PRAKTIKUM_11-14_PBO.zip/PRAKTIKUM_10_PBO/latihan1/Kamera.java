package latihan1;

public interface Kamera {
    public void setPixel(float pixel);
    public void ambilGambar();
}
