package latihan1;

public interface Radio {
    public void setGelombang(String gel);
}
