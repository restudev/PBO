package contoh;

class Bangun3DDemo {
    public static void main(String[] args) {
        BujurSangkar bs = new BujurSangkar(5);
        bs.cetakKeliling();
        bs.cetakLuas();
    }
}
