package latihan2;

class Bebek extends Binatang {
    void makan() {
        System.out.println("Bebek Makan..........");
    }
    void tidur() {
        System.out.println("Bebek tidur..........");
    }
}
